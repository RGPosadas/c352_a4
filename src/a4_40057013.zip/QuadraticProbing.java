public class QuadraticProbing extends HashTable {
    /**
     * Attributes
     */
    private MyMapElement[] QPTable;
    
}