public class SeparateChaining extends HashTable {

}